# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['helpers', 'indicators', 'storage', 'strategies', 'utilities']

package_data = \
{'': ['*']}

install_requires = \
['black>=22.12.0,<23.0.0',
 'boto3>=1.26.52,<2.0.0',
 'pandas>=1.5.3,<2.0.0',
 'polars>=0.15.16,<0.16.0',
 'polygon-api-client>=1.6.1,<2.0.0',
 'pyarrow>=10.0.1,<11.0.0',
 'smart-open>=6.3.0,<7.0.0']

setup_kwargs = {
    'name': 'crowemi-trades',
    'version': '0.1.0',
    'description': '',
    'long_description': 'This is going to be a reuseable collection of code to help automate some of the tedious work around trading forex. Here are some initial thoughts of what it will help do:\n\n- Create a framework to backtest strategies.\n- Actually trade.',
    'author': 'crowemi',
    'author_email': 'crowemi@hotmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)

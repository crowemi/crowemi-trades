This is going to be a reuseable collection of code to help automate some of the tedious work around trading forex. Here are some initial thoughts of what it will help do:

- Create a framework to backtest strategies.
- Actually trade.
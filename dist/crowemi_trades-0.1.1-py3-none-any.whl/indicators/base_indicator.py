import duckdb

class BaseIndicator:
    def __init__(self) -> None:
        pass
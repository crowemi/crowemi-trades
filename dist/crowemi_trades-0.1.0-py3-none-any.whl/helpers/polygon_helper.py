import os
import time
import functools

from polygon import RESTClient

class Throttle:
    def __init__(self, func):
        functools.update_wrapper(self, func)
        self.func = func
        self.num_calls = 0

    def __call__(self, *args, **kwargs):
        self.num_calls += 1
        print(f"Call {self.num_calls} of {self.func.__name__!r}")
        return self.func(*args, **kwargs)

class PolygonHelper():
    """A helper class to abstract common polygon functionality."""

    def __init__(self, polygon_token: str = None) -> None:
        # if token not passed, is it in env
        polygon_token = polygon_token if polygon_token is not None else os.getenv('polygon_key')
        if not polygon_token:
            raise Exception("No polgygon token found.")
        self._client = RESTClient(api_key=polygon_token)

        self.requests = 0

    @Throttle
    def get_aggs(self, ticker: str, interval: str, interval_period: int, start_date: str, end_date: str):
        return self._client.get_aggs(
            ticker,
            interval_period,
            interval,
            start_date,
            end_date
        )
